'''
파일명 : __init__.py
Description:
생성일: 2023-01-25
생성자: 김유석
since 2023.01.10
copyright (c) by kimyusuk All right reserved.
'''


def main():
    pass


main()
