from .base import * # base에 있는 모든 내용을 사용한다. allowed_host만 따로 사용하겠다 라는뜻

ALLOWED_HOSTS = []